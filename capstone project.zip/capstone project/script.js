// Hold references to page elements so we don't re-query the DOM on every click
let tableBody
let loadBtn

// Wait for the HTML to finish loading before touching the DOM
document.addEventListener('DOMContentLoaded', () => {
  // Grab the table body where rows get inserted
  tableBody = document.querySelector('#populationTable tbody')
  // Grab the "Load Data" button
  loadBtn = document.getElementById('loadPopulationBtn')
  // Wire the button click to the fetch function
  loadBtn.addEventListener('click', loadBtcsData)
})

// Fetches the Census BtOS data from the API and renders it into the table
function loadBtcsData () {
  // Clear the table so a second load doesn't stack rows
  tableBody.innerHTML = ''
  // Disable the button while the request is running (prevents double clicks)
  loadBtn.disabled = true
  // Hide the table again while we wait for fresh data
  document.getElementById('populationTable').classList.add('hidden')
  // Show a loading message below the button
  document.getElementById('loadInfo').textContent = 'Loading...'

  axios
    .get('https://www.census.gov/hfp/btos/api/periods/1/data', {
      // Pass the period as a query param so we get a specific slice of data
      params: { PERIOD: '1/2025' }
    })
    .then(function (response) {
      // Make sure the response is an array before we try to loop over it
      const records = Array.isArray(response.data) ? response.data : []
      // Build the table rows from the records
      renderRecords(records)
    })
    .catch(function (error) {
      // Show a friendly alert if the request fails
      alert('An error occurred: ' + error.message)
    })
    .finally(function () {
      // Re-enable the button whether we succeeded or failed
      loadBtn.disabled = false
    })
}

// Builds and inserts the table rows for the given records
function renderRecords (records) {
  // Only render the first 250 records so a huge response doesn't freeze the browser
  const rows = records.slice(0, 250)
  // A fragment lets us build all rows off-screen, then insert once (faster)
  const frag = document.createDocumentFragment()

  rows.forEach(function (rec) {
    // Create one table row per record
    const tr = document.createElement('tr')

    // These are the columns we want to display, in order
    const fields = [
      'PERIOD_ID',
      'DATE_RANGE',
      'STATE',
      'NAICS2',
      'QUESTION',
      'ANSWER',
      'INDEX_ESTIMATE_PERCENTAGE',
      'INDEX_STANDARD_ERROR'
    ]

    // Create a table cell for each field and fill it with the record's value
    fields.forEach(function (field) {
      const td = document.createElement('td')
      // Show an empty cell instead of the word "null" when a value is missing
      td.textContent = rec[field] == null ? '' : rec[field]
      tr.append(td)
    })

    // Add the finished row to the fragment
    frag.append(tr)
  })

  // Replace whatever was in the table with the new rows
  tableBody.innerHTML = ''
  tableBody.append(frag)

  // Update the info line with how many rows we drew vs. total records
  const info = document.getElementById('loadInfo')
  info.textContent =
    'Showing ' + rows.length + ' of ' + records.length + ' records from period(s) returned.'
  // Show the table now that it has content
  document.getElementById('populationTable').classList.remove('hidden')
}